/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 3, 2015, 1:48 AM
 * Purpose: Find a cars mpg by input/output
 */

//System Libraries
#include <iostream>
using namespace std;
 
//User Libraries
 
//Global Constants
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int galGas; //How many gallons of gas are held in the car
    unsigned int miDrvn; //How many miles can be driven on a full tank of gas
    unsigned int mpg; //How many miles the car gets per gallon
    
    //Prompt user to input values
    cout<<"Input how many gallons of gas your car holds."<<endl;
    cin>>galGas;
    cout<<"Input how many miles can be driven on a full tank."<<endl;
    cin>>miDrvn;
     
    //Preform division
    mpg = miDrvn / galGas;
    
    //Output the Results
    cout<<"Your car gets "<<mpg<<"(mpg)"<<endl;
    
    //Winter is Coming!
    return 0;
}

