/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 3, 2015, 4:19 PM
 * Purpose: Report a stores total income plus sales tax
 */

//System Libraries
#include <iostream>
#include <iomanip>

using namespace std;
 
//User Libraries
 
//Global Constants
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    string mnth;
    unsigned int yr;
    float totCol;
    float sales;
    float contTx;
    float statTx;
    float totTax;
    
    //Prompt user to input values
    cout<<"What month is it?"<<endl;
    cin>>mnth;
    cout<<"What is the year?"<<endl;
    cin>>yr;
    cout<<"What was the total amount collected?"<<endl;
    cin>>totCol;
            
    //Preform Calculations
    sales = totCol / 1.06;
    contTx = sales * 0.02;
    statTx = sales * 0.04;
    totTax = contTx + statTx;
            
    //Output results
    cout<<"Month: "<<mnth<<" Year: "<<yr<<endl;
    cout<<"---------------"<<endl;
    cout<<setprecision(2)<<showpoint<<fixed;
    cout<<"Total Collected:       $ "<<totCol<<endl;
    cout<<"Sales:                 $ "<<sales<<endl;
    cout<<"County Sales Tax:      $ "<<contTx<<endl;
    cout<<"State Sales Tax:       $ "<<statTx<<endl;
    cout<<"Total Sales Tax:       $ "<<totTax<<endl;
    
    //Winter is Coming!
    return 0;
}

