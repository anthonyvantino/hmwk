/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 3, 2015, 3:47 PM
 * Purpose: Play a word game with user
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;
 
//User Libraries
 
//Global Constants
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    string name;
    string city;
    string college;
    string prof;
    string animal;
    string petName;
    unsigned int age;
    
    //Prompt User to input values
    cout<<"what is your name?"<<endl;
    getline(cin, name);
    cout<<"what is your age?"<<endl;
    cin>>age;
    cout<<"what is your cities name?"<<endl;
    cin>>city;
    cout<<"what is your colleges name?"<<endl;
    cin>>college;
    cout<<"what is your profession?"<<endl;
    cin>>prof;
    cout<<"Name an animal."<<endl;
    cin>>animal;
    cout<<"what is your pets name?"<<endl;
    cin>>petName;
    
    //Output Results
    cout<<"There once was a person named "<<name<<" who lived in "<<city<<'.'<<
    " At the age of \n"<<age<<", "<<name<<" went to college at "<<college<<". "
    <<name<<" graduated and went to work \nas a "<<prof<<". "<<"Then, "<<name
    <<" adopted a(n) "<<animal<<" named "<<petName<<". "<<"They \nboth lived "
    "happily ever after!"<<endl;
    
    //Winter is Coming!
    return 0;
}

