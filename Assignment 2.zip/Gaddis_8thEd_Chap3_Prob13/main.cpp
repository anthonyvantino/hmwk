/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 3, 2015, 3:09 PM
 * Purpose: Convert US Currency to Yen & Euro
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;
 
//User Libraries
 
//Global Constants
 const float YEN_PER_DOLLAR = 122.88;
 const float EURO_PER_DOLLAR = 0.90;
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    float usDol1;
    float usDol2;
    float chiYen;
    float euro;
    
    //Prompt user to input values
    cout<<"How many US Dollars would you like to convert to Yen?"<<endl;
    cin>>usDol1;
    cout<<"How many US Dollars would you like to convert to Euro?"<<endl;
    cin>>usDol2;
    
    //Preform Conversion
    chiYen = usDol1 * 112.88;
    euro = usDol2 * 0.90;
    
    //Output Results
    cout<<setprecision(2)<<showpoint<<fixed;
    cout<<'$'<<usDol1<<" converted to Yen = "<<chiYen<<"(yen)"<<endl;
    cout<<'$'<<usDol2<<" converted to Euro = "<<euro<<"(euro)"<<endl;
    
    //Winter is Coming!
    return 0;
}

