/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 3, 2015, 2:15 AM
 * Purpose: Input sales get dollar amount as output that has 2 decimal points
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;
 
//User Libraries
 
//Global Constants
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int classA = 15.00; //How much Class A seating costs
    unsigned int classB = 12.00; //How much Class B seating costs
    unsigned int classC = 9.00; //How much Class C seating costs
    float totA; //Income from Class A seating sold
    float totB; //Income from Class B seating sold
    float totC; //Income from Class C seating sold
    
    //Prompt user for inputs
    cout<<"How many tickets were sold for Class A seating"<<endl;
    cin>>classA;
    cout<<"How many tickets were sold for Class B seating"<<endl;
    cin>>classB;
    cout<<"How many tickets were sold for Class C seating"<<endl;
    cin>>classC;
    
    //Preform multiplication
    totA = classA * 15.00;
    totB = classB * 12.00;
    totC = classC * 9.00;
    
    //Output Results
    cout<<setprecision(2)<<showpoint<<fixed;
    cout<<"Total made on Class A seating $"<<totA<<endl;
    cout<<"Total made on Class B seating $"<<totB<<endl;
    cout<<"Total made on Class C seating $"<<totC<<endl;
    
    //Winter is Coming!
    return 0;
}

