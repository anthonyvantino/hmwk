/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 3, 2015, 2:18 PM
 * Purpose: Calculate how much a movie theater would make in one night of sales
 */

//System Libraries
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
 
//User Libraries
 
//Global Constants
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    string movTit; //Movie Title
    unsigned int adTic = 10.00; //Price of the Adult Tickets
    unsigned int chiTic = 6.00; //Price of the Child Tickets
    float gross; //Gross income for the theater
    float net; //Net box office profit
    float amntPd; //Amount paid to distributor
    
    //Prompt to input values
    cout<<"What was the name of the film?"<<endl;
    getline(cin, movTit);
    cout<<"How many Adult Tickets were sold?"<<endl;
    cin>>adTic;
    cout<<"How many Child Tickets were sold?"<<endl;
    cin>>chiTic;
    
    //Preform Division
    gross = (adTic * 10) + (chiTic * 6);
    net = gross * 0.2;
    amntPd = gross - net;
    
    //Output the Results
    cout<<"Movie Name:                            "<<movTit<<endl;
    cout<<"Adult Tickets Sold:                    "<<adTic<<endl;
    cout<<"Child Tickets Sold:                    "<<chiTic<<endl;
    cout<<setprecision(2)<<showpoint<<fixed;
    cout<<"Gross Box Office Profit:              $"<<gross<<endl;
    cout<<"Net Box Office Profit:                $"<<net<<endl;
    cout<<"Amount Paid to Distributor:           $"<<amntPd<<endl;
    
    //Winter is Coming!
    return 0;
}

