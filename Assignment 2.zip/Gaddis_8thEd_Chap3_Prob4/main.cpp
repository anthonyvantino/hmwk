/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 3, 2015, 2:36 AM
 * Purpose: Calculate the Average rainfall for three months
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;
 
//User Libraries
 
//Global Constants
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    string mnth1;
    string mnth2;
    string mnth3;
    unsigned int amntRn1;
    unsigned int amntRn2;
    unsigned int amntRn3;
    unsigned int avrgRn;
    
    //Prompt User to input values
    cout<<"Input 3 months to calculate the average rainfall."<<endl;
    cin>>mnth1;
    cin>>mnth2;
    cin>>mnth3;
    cout<<"Input the rainfall for "<<mnth1<<" in inchs."<<endl;
    cin>>amntRn1;
    cout<<"Input the rainfall for "<<mnth2<<" in inchs."<<endl;
    cin>>amntRn2;
    cout<<"Input the rainfall for "<<mnth3<<" in inchs."<<endl;
    cin>>amntRn3;
    
    //Preform Average
    avrgRn = amntRn1 + amntRn2 + amntRn2 / 3;
    
    //Output the Results
    cout<<"The average rainfall for "<<mnth1<<", "<<mnth2<<", and "<<mnth3<<" is "<<avrgRn<<"(inchs)"<<endl;
    
    //Winter is Coming!
    return 0;
}

