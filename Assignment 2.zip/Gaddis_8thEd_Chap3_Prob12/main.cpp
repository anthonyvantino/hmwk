/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 3, 2015, 2:58 PM
 * Purpose: Convert Celsius to Fahrenheit 
 */

//System Libraries
#include <iostream>
using namespace std;
 
//User Libraries
 
//Global Constants
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int fahrn;
    unsigned int cels;
    
    //Prompt to input values
    cout<<"What is the degree in Celsius?"<<endl;
    cin>>cels;
    
    //Preform Conversion
    fahrn = 1.8*cels + 32;
    
    //Output results
    cout<<cels<<" (degrees) Celsius converted to Fahrenheit is "<<fahrn<<"(degrees)"<<endl;
    
    //Winter is Coming!
    return 0;
}

