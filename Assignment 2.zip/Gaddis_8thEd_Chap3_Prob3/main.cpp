/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 5, 2015, 3:56 PM
 * Purpose: Find average test scores
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;
 
//User Libraries
 
//Global Constants
 
//Function Prototypes
 
//Execution begins here!
int main(int argc, char** argv) {
    //Declare Variables
    int test1;
    int test2;
    int test3;
    int test4;
    int test5;
    float avrg;
    
    //Prompt User to Input Test Scores
    cout<<"Please input the first test score.\n";
    cin>>test1;
    cout<<"Please input the second test score.\n";
    cin>>test2;
    cout<<"Please input the third test score.\n";
    cin>>test3;
    cout<<"Please input the fourth test score.\n";
    cin>>test4;
    cout<<"Please input the fifth test score.\n";
    cin>>test5;
    
    
    //Preform average
    avrg = (test1 + test2 + test3 + test4 + test5) / 5;
    
    //Output the results
    cout<<setprecision(1)<<showpoint<<fixed;
    cout<<"Your test average is %"<<avrg<<endl;
    
    return 0;
}

