/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 4, 2015, 12:10 AM
 * Purpose: using Conditional Operator to find min/max
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins here!
int main(int argc, char** argv) {
    //Declare Variables
    int first;
    int second;
    
    //Prompt user for input
    cout<<"Input two numbers"<<endl;
    cin>>first>>second;
    
    //Conditional Operator
    if (first > second)
        cout<<first<<" is bigger than "<<second<<endl;
    else
        cout<<second<<" is bigger than "<<first<<endl;
    return 0;
}

