/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 4, 2015, 12:10 AM
 * Purpose: Calculate BMI
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins here!
int main(int argc, char** argv) {
    //Declare Variables
    float wght; //The Weight of a person
    float hght; //The Height of a person
    float bmi; //Body Mass Index
    
    //Input values
    cout<<"What is your weight in lbs?"<<endl;
    cin>>wght;
    cout<<"What is your height in inches?"<<endl;
    cin>>hght;
    
    //Preform BMI Calculations
    bmi = (wght*703) / pow(hght,2);
    
    //Output the results
    cout<<fixed<<setprecision(2)<<endl;
    cout<<"Your BMI = "<<bmi<<endl;
    if (bmi < 18.5){
        cout<<"Your BMI is not above 18.5. You are Underweight."<<endl;
    }
    else if (bmi > 25){
        cout<<"Your BMI is over 25. You are Overweight"<<endl;
    }
    return 0;
}

