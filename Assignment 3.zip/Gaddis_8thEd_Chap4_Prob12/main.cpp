/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 2, 2015, 12:10 AM
 * Purpose: selling many units at a discount
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins here!
int main(int argc, char** argv) {
    //Declare Variables
    float pack = 99.00; //Software Package costing $99.00
    float units; //How many units purchased
    float totPur; //Total amount paid
    
    //Input how many units sold
    cout<<"How many units are you purchasing"<<endl;
    cin>>units;
    
    //Preform Math
    totPur = units * pack;
    
    //Output the results
    cout<<fixed<<setprecision(2)<<endl;
    if (units <= 0){
        cout<<"That is not a valid amount of unit(s) purchasable. Try Again."<<endl;
    }
    else if (units > 0  && units <=9){ 
        cout<<"You purchased "<<units<<endl;
        cout<<"For a grand total of $"<<totPur<<endl;
    }
    else if (units >= 10 && units <= 19){
        cout<<"You purchased "<<units<<" units at a 20% discount."<<endl;
        cout<<"For a grand total of $"<<(totPur * .20)<<endl;
    }
    else if (units >= 20 && units <= 49){
        cout<<"You purchased "<<units<<" units at a 30% discount."<<endl;
        cout<<"For a grand total of $"<<(totPur * .30)<<endl;
    }
    else if (units >= 50 && units <= 99){
        cout<<"You purchased "<<units<<" units at a 40% discount."<<endl;
        cout<<"For a grand total of $"<<(totPur * .40)<<endl;
    }
    else if (units >= 100){
        cout<<"You purchased "<<units<<" units at a 50% discount."<<endl;
        cout<<"For a grand total of $"<<(totPur * .50)<<endl;
    }
    else
        cout<<"Invalid number"<<endl;
    
    return 0;
}

