/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 4, 2015, 12:10 AM
 * Purpose: Calculate Mass and Weight
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins here!
int main(int argc, char** argv) {
    //Declare Variables
    float mass; //The mass of the object
    float wght; //The weight of the objects
    
    //Input values
    cout<<"What is the objects mass?"<<endl;
    cin>>mass;
    
    //Preform BMI Calculations
    wght = mass * 9.8;
    
    //Output the results
    cout<<fixed<<setprecision(2)<<endl;
    cout<<"The Objects Weight = "<<wght<<endl;
    if (wght < 10){
        cout<<"The objects weight is not above 10 newtons. It is too light."<<endl;
    }
    else if (wght > 1000){
        cout<<"The objects weight is over 1000 newtons. It is too heavy."<<endl;
    }
    return 0;
}