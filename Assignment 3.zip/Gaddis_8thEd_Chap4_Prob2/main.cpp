/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 2, 2015, 12:10 AM
 * Purpose: Convert numbers to Roman Numerals
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins here!
int main(int argc, char** argv) {
 //Declare Variables
    int num;
    
    //Prompt User for Inputs
    cout<<"Input a number between 1 - 10."<<endl;
    cin>>num;
    if (num <= 0 || num > 10){
        int num;
        cout<<"The number you input was not 1 - 10. Try Again."<<endl;
        cin>>num;
    }
    else{
        //Switch case
        switch(num){
            case 1: {
                cout<<"The Roman Numeral for one is I"<<endl;
                break;
            }
            case 2: {
                cout<<"The Roman Numeral for two is II"<<endl;
                break;
            }
            case 3: {
                cout<<"The Roman Numeral for three is III"<<endl;
                break;
            }
            case 4: {
                cout<<"The Roman Numeral for four is IV"<<endl;
                break;
            }
            case 5: {
                cout<<"The Roman Numeral for five is V"<<endl;
                break;
            }
            case 6: {
                cout<<"The Roman Numeral for six is VI"<<endl;
                break;
            }
            case 7: {
                cout<<"The Roman Numeral for seven is VII"<<endl;
                break;
            }
            case 8: {
                cout<<"The Roman Numeral for eight is VIII"<<endl;
                break;
            }
            case 9: {
                cout<<"The Roman Numeral for nine is IX"<<endl;
                break;
            }
            case 10: {
                cout<<"The Roman Numeral for ten is X"<<endl;
                break;
            }
        }
    }
    //Winter is Coming!
    return 0;
}

