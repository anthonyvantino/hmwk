/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 2, 2015, 12:10 AM
 * Purpose: Find how many book club points you have
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins here!
int main(int argc, char** argv) {
 //Declare Variables
    int books; //How many books purchased this month
    
    //Prompt User for Input
    cout<<"How many books have you bought this month?"<<endl;
    cin>>books;
    
    //if/else loop
    if (books < 1){
        cout<<"You have not purchased any books this month so you have earned 0 points!"<<endl;
    }
    else if (books == 1){
        cout<<"You have purchased 1 book this month so you have earned 5 points!"<<endl;
    }
    else if (books == 2){
        cout<<"You have purchased 2 books this month so you have earned 15 points!"<<endl;
    }
    else if (books == 3){
        cout<<"You have purchased 3 books this month so you have earned 30 points!"<<endl;
    }
    else if (books >= 3){
        cout<<"You have purchased "<<books<<" books this month you have earned 60 points!"<<endl;
    }
    else 
        cout<<"You did not input a valid number. Try again."<<endl;
    
    return 0;
}

