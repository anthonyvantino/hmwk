/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 2, 2015, 12:10 AM
 * Purpose: Calculate phone bill
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins here!
int main(int argc, char** argv) {
 //Declare Variables
    int choice; //To hold a menu choice
    float min; //Minutes used
    float xMin; //Minutes that went over limit
    float totPaid; //Total bill
    float packA = 1; //Menu choice
    float packB = 2; //Menu choice
    float packC = 3; //Menu choice
    
    //Constants for package rates
    const int a = 39.99; //Package A
    const int b = 59.99; //Package B
    const int c = 69.99; //Package C
    
    //Prompt User input
    cout<<"Which Mobile Service Provider Package would you like?"<<endl;
    cout<<"a. Package A: $39.99 a month w/ 450min."<<endl;
    cout<<"b. Package B: $59.99 a month w/ 900min."<<endl;
    cout<<"c. Package C: $69.99 a month w/unlimited minutes."<<endl;
    cout<<"Enter 1, 2, or 3."<<endl;
    cin>>choice;
    
    //Output Results
    cout<<fixed<<showpoint<<setprecision(2);
    if (choice == packA){
        cout<<"How many minutes did you use?"<<endl;
        cin>>min;
        cout<<"How many minutes did you go over?"<<endl;
        cin>>xMin;
        totPaid = a + (xMin * 0.45);
        cout<<"Your total bill = $"<<totPaid<<endl;
    }
    else if (choice == packB){
        cout<<"How many minutes did you use?"<<endl;
        cin>>min;
        cout<<"How many minutes did you go over?"<<endl;
        cin>>xMin;
        totPaid = b + (xMin * 0.40);
        cout<<"Your total bill = $"<<totPaid<<endl;
    }
    else if (choice == packC){
        cout<<"How many minutes did you use?"<<endl;
        cin>>min;
        totPaid = c;
        cout<<"Your total bill = $"<<totPaid<<endl;
    }
    else 
        cout<<"Invalid input. Try Again."<<endl;
    
    return 0;
}

