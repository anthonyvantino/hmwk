/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 27, 2015, 12:25 PM
 * Purpose: Compute the tax and tip of a Restaurant Bill
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
     float meal = 88.67; //The charge for the meal alone
     float meTax = 0.0675; //The amount of tax on the meal
     float totTax; //Total amount of tax
     float totMeal = 94.65; //Amount spent on meal + tax
     float tip = 0.20; //% given as tip
     float totTip; //Total given as tip
     float totBill; //Total amount spent
    //Perform Values
     totTax = 88.67 * 0.0675;
     totTip = 94.65 * 0.20;
     totBill = 94.65 + 18.93;
    //Output Results
    cout<<"The cost of the meal alone = $"<<meal<<endl;
    cout<<"The total tax amount = $"<<totTax<<endl;
    cout<<"The Tip = $"<<totTip<<endl;
    cout<<"The total bill = $"<<totBill<<endl;
    //Exit Stage Right!
    return 0;
}