/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 27, 2015, 12:25 PM
 * Purpose: Find how much higher the ocean's level will be years down the line
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
     float risRate = 1.5; //how much the ocean is rising every year
     float riseyr5; //How high the ocean's level will be in five years
     float riseyr7; //How high the ocean's level will be in seven years
     float riseyrX; //How high the ocean's level will be in ten years
    //Perform Values
     riseyr5 = 1.5 * 5;
     riseyr7 = 1.5 * 7;
     riseyrX = 1.5 * 10;
    //Output Results
     cout<<"In five years the ocean will be  = "<<riseyr5<<" ml higher!"<<endl;
     cout<<"In seven years the ocean will be = "<<riseyr7<<" ml higher!"<<endl;
     cout<<"In ten years the ocean will be   = "<<riseyrX<<" ml higher!"<<endl;
    //Exit Stage Right!
    return 0;
}