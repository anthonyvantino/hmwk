/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 27, 2015, 12:25 PM
 * Purpose: Finding how many acres are in 391,876 square feet of land
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
     float acre = 43560; //The total square feet of one acre
     float land = 391876; //How much land given
     float acresF; //How many acres were found in the amount given from land
    //Perform Values
     acresF = 391876 / 43560;
    //Output Results
     cout<<"There are a total of "<<acresF<<" acres found in 391876 sq ft of land!"<<endl;
    //Exit Stage Right!
    return 0;
}