/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 28, 2015, 12:25 PM
 * Purpose: Use only one cout statement to display multiple lines of code
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
    
    //Perform Values
    
    //Output Results
     cout<<"Anthony Vantino \n"<<"12345 Fake Street, Riverside, CA 92508 \n"<<"1-(951)123-4567 \n"<<"Computer Science \n"<<endl;
    //Exit Stage Right!
    return 0;
}