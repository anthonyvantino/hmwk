/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 27, 2015, 12:25 PM
 * Purpose: Compute the total annual pay
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
     float payAmount = 2200.00; //What the employee is payed every two weeks
     float payPeriods = 26; //How many pay periods are in a year
     float annualPay; //How much the employee will make in a year
    //Perform Values
     annualPay = 2200.00 * 26;
    //Output Results
     cout<<"The employee will annually make = $"<<annualPay<<endl;
    //Exit Stage Right!
    return 0;
}