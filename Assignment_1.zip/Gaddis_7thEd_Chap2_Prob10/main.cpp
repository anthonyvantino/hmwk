/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 27, 2015, 12:25 PM
 * Purpose: Find how many miles you get per gallon on gas
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
     float mpg; //Miles Per Gallon
     float miDriv = 375; //Miles Driven
     float Gallons = 15; //How many gallons of gas the car can hold
    //Perform Values
     mpg = 375 / 15;
    //Output Results
     cout<<"The car gets = "<<mpg<<" Miles per gallon!"<<endl;
    //Exit Stage Right!
    return 0;
}