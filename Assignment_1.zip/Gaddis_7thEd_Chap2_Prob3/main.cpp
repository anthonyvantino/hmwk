/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 27, 2015, 12:25 PM
 * Purpose: Compute Sales Tax
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
     float totTax; //The total tax
     float stateT = 0.04; //State Sales Tax
     float contT = 0.02; //County Sales Tax
    //Perform Values
     totTax = 95.00 * 0.06;
 
    //Output Results
    cout<<"The total tax for a $95 purchase = $"<<totTax<<endl;
    //Exit Stage Right!
    return 0;
}