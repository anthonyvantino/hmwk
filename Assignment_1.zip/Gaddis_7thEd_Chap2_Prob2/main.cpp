/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 27, 2015, 12:25 PM
 * Purpose: Predict Sales of a company
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
    float ecsDiv = 0.58; //East Coast Sales Division that generates 58% total sales 
    float ecSales = 8.6e5; //East Coast Sales prediction next year
    float preSale; //Predicted Sales for the division next year
    //Perform Values
    preSale = 8.6e5 * 0.58;
 
    //Output Results
    cout<<"The Predicted sales total for next year = "<<preSale<<endl;
    //Exit Stage Right!
    return 0;
}