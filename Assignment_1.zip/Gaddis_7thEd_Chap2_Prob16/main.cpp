/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on June 28, 2015, 12:25 PM
 * Purpose: Write a program that displays an image instead of text
 */
 
#include <iostream>
using namespace std;
//User Libraries
 
//Global Constants

//Function Prototypes
 
//Execution Begins!
 int main(int argc, char** argv) {
    //Declare variables
   
    //Perform Values
    
    //Output Results
     cout<<"        *           "<<endl;
     cout<<"       ***           "<<endl;
     cout<<"      *****           "<<endl;
     cout<<"     *******           "<<endl;
     cout<<"      *****           "<<endl;
     cout<<"       ***           "<<endl;
     cout<<"        *           "<<endl;
    //Exit Stage Right!
    return 0;
}